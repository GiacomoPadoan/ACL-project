<?php
session_start();
if(isset($_SESSION["user_id"])){
  $mysqli = require __DIR__ . "/../PurePhp/configDB.php";
  $sql= "SELECT * FROM utenti WHERE id = {$_SESSION["user_id"]}";
  $result =$mysqli->query($sql);
  //print_r($_SESSION);
  $user = $result->fetch_assoc();
  switch($user["ruolo"]){
    case "Admin":
      $sql = "SELECT id, cognome, nome, ruolo, area FROM utenti WHERE id!={$user["id"]}";
    break;
    case "Capo_area":
      $sql = "SELECT id, cognome, nome, ruolo, area FROM utenti WHERE id!={$user["id"]} AND area='".$user["area"]."' ";
    break;
    case "Commerciale":
      $sql = "SELECT id, cognome, nome, ruolo, area FROM utenti WHERE portafoglio_di={$user["id"]}";
    default:
    echo "errore nella scelta dei permessi";
  }
  $clienti=$mysqli->query($sql);
}
else{
  echo "ERRORE caricamento sessione";
}
?>
<!DOCTYPE html>
<head>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel=”stylesheet” href=”https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css” />
    <title>Dashboard</title>
    <style type="text/css">
    body{
    /* fallback for old browsers */
    background: #6a11cb;
    
    /* Chrome 10-25, Safari 5.1-6 */
    background: -webkit-linear-gradient(to right, rgba(106, 17, 203, 1), rgba(37, 117, 252, 1));
    
    /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
    background: linear-gradient(to right, rgba(106, 17, 203, 1), rgba(37, 117, 252, 1))
    }
    .sidebar{
        float: left;
        background-color: #343A40;
        height: 100%;
    }
    .nav-item{
        margin: 20px;
        margin-top: 20px;
    }
    .flex-column{
        background-color: #343A40
    }
    </style>
</head>
<body>
  <!--colonna a sinistra info account-->
  <div class="sidebar container-flex vh-100" id="sidebar">
      <div class="card bg-dark text-white" style="width: 18rem;">
        <div class="card-body">
          <h5 class="card-title" id="nominativo"><?= htmlspecialchars($user["nome"]) ?> <?= htmlspecialchars($user["cognome"]) ?></h5>
          <h6 class="card-subtitle mb-2 text-muted" id="ruolo"><?= htmlspecialchars($user["ruolo"]) ?></h6>
          <a href="../PurePhp/logout.php" class="card-link" style = "color: red">Log-out</a>
        </div>
      </div>
  <!--colonna a sinistra selezione clienti e fatture-->
      <nav class="nav nav-pills nav flex-column vh-100">
        <a id="fatture" class="nav-item nav-link" href="D-fatture.php" onclick="hey()">Fatture</a>
        <a id="c_fattura" class="nav-item nav-link disabled" href="#" onclick="addFattura()">Creazione Fattura
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-plus-square" viewBox="-3 -4 20 20">
            <path d="M14 1a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1h12zM2 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H2z"/>
            <path d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4z"/>
          </svg>
        </a>
        <a id="clienti" class=" nav-item nav-link active" href="#">Clienti</a>
      </nav>
  </div>
  <!--sezione clienti-->
  <div class="container-flex col-10 col-md-8" style="float:left; margin-top: 10px;">
  <!--search bar-->
  <div class="input-group mb-3">
    <input type="text" class="form-control" placeholder="ricerca utente" aria-label="Recipient's username" aria-describedby="basic-addon2">
    <div class="input-group-append">
        <button type="button" class="btn btn-info">Cerca</button>
    </div>
  </div>
  <!--elenco clienti-->
  <table class="table table-striped table-bordered table-dark flex-column" bg>
    <thead>
      <tr>
        <th scope="col">ID</th>
        <th scope="col">Cognome</th>
        <th scope="col">Nome</th>
        <th scope="col">Ruolo</th>
        <th scope="col">Area</th>
        <th scope="col">Crea / Modifica le sue fatture</th>
      </tr>
    </thead>
    <tbody>
      <?php
      if ($clienti->num_rows > 0) {
          foreach ($clienti as $row) { ?>
              <tr>
                <td><?= $row["id"] ?></td>
                <td><?= $row["cognome"] ?></td>
                <td><?= $row["nome"] ?></td>
                <td><?= $row["ruolo"] ?></td>
                <td><?= $row["area"] ?></td>
                <td><button type='button' class='btn btn-info'>Fatture</button></td>
              </tr>
      <?php }
        }?>
    </tbody>
  </table>
  </div>

  <script type="text/javascript">   
  </script>
</body>
</html>